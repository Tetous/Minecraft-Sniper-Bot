# SwiftLite
 Free Powerful Minecraft Name Sniper

# Usage:
 1. Make sure you have Python 3.8 installed
 2. Make sure you have the library 'requests-futures' installed
 3. Create a file named Accounts.txt
 4. Put the accounts you want to snipe with in that file like email:password
 5. (optional) Put the skin you want to upload when you snipe a name in the folder with name 'Skin.png'
 6. Run SwiftLite.py and the rest explains itself

 If you are having any issues feel free to join my discord server: https://discord.gg/2QyckKv